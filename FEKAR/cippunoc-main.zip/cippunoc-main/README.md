- git clone
- configurar el .env
- composer install
- npm install
- npm run dev
- php aritsan key:generate
# cippunoc
